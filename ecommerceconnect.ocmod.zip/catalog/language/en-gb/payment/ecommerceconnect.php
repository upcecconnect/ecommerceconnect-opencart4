<?php
// Heading
$_['heading_title']      = 'eCommerceConnect Payment';

// Text
$_['text_title']         = '';
$_['text_description']   = '';

//Error gateway payment
$_['error_signature']     = 'Error: Gateway response have invalid signature!';